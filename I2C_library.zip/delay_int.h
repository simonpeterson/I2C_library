/* 
 * File:   delay_int.h
 * Author: Simon
 *
 * Created on 25. Februar 2018, 12:09
 */

#ifndef DELAY_INT_H
#define	DELAY_INT_H
#ifdef	__cplusplus
extern "C" {
#endif
void delay(int delay_in_ms);



#ifdef	__cplusplus
}
#endif

#endif	/* DELAY_INT_H */

