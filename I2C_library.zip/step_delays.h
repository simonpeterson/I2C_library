/* 
 * File:   step_delay.h
 * Author: Simon
 *
 * Created on 25. Februar 2018, 11:46
 */

#ifndef STEP_DELAYS_H
#define	STEP_DELAYS_H

#ifdef	__cplusplus
extern "C" {
#endif
    void step_delay(void);



#ifdef	__cplusplus
}
#endif

#endif	/* STEP_DELAY_H */

